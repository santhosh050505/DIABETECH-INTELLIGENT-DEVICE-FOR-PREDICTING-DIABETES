# diabetes_prediction
Preview of the Project

![](images/1.PNG)
![](images/2.PNG)
![](images/3.PNG)
![](images/4.PNG)
